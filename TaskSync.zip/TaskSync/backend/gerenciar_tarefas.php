<?php
session_start();
include('conexao.php');

// Obter tarefas
$sql = "
SELECT t.id, t.descricao, t.setor, t.prioridade, t.status, t.data_cadastro, u.nome AS nome_usuario
FROM tarefas t
JOIN usuarios u ON t.id_usuario = u.id
ORDER BY t.data_cadastro DESC
";
$tarefas = $conn->query($sql);

// Processar ação
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['tarefa_id'], $_POST['acao'])) {
    $id = $_POST['tarefa_id'];
    $acao = $_POST['acao'];

    if ($acao === "excluir") {
        $stmt = $conn->prepare("DELETE FROM tarefas WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    } elseif (in_array($acao, ['A Fazer', 'Fazendo', 'Concluído'])) {
        $stmt = $conn->prepare("UPDATE tarefas SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $acao, $id);
        $stmt->execute();
    }

    header("Location: gerenciar_tarefas.php");
    exit();
}

// Organizar por status
$tarefas_por_status = [
    'A Fazer' => [],
    'Fazendo' => [],
    'Concluído' => [],
];

while ($tarefa = $tarefas->fetch_assoc()) {
    $tarefas_por_status[$tarefa['status']][] = $tarefa;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Tarefas</title>
    <link rel="stylesheet" href="../frontend/style.css">
</head>
<body>
    <h2>Gerenciamento de Tarefas</h2>
    <div style="text-align: center;">
        <a href="cadastro_tarefa.php" class="btn">Nova Tarefa</a>
    </div>

    <div class="kanban-board">
        <?php foreach (['A Fazer', 'Fazendo', 'Concluído'] as $status): ?>
            <div class="kanban-column">
                <h3><?= $status ?></h3>
                <?php foreach ($tarefas_por_status[$status] as $tarefa): ?>
                    <div class="task-card">
                        <strong><?= htmlspecialchars($tarefa['descricao']) ?></strong>
                        <div><small>Usuário:</small> <?= htmlspecialchars($tarefa['nome_usuario']) ?></div>
                        <div><small>Setor:</small> <?= ucfirst($tarefa['setor']) ?></div>
                        <div><small>Prioridade:</small> <?= ucfirst($tarefa['prioridade']) ?></div>
                        <div><small>Data:</small> <?= date('d/m/Y H:i', strtotime($tarefa['data_cadastro'])) ?></div>

                        <form method="post" class="inline" onsubmit="return confirmarAcao(this);">
                            <input type="hidden" name="tarefa_id" value="<?= $tarefa['id'] ?>">
                            <select name="acao" required>
                                <option value="">Status</option>
                                <?php foreach (['A Fazer', 'Fazendo', 'Concluído'] as $novo_status): ?>
                                    <?php if ($novo_status !== $tarefa['status']): ?>
                                        <option value="<?= $novo_status ?>"><?= $novo_status ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <option value="excluir">Excluir</option>
                            </select>
                            <button type="submit">Aplicar</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        function confirmarAcao(form) {
            const acao = form.acao.value;
            if (acao === 'excluir') {
                return confirm('Tem certeza que deseja excluir esta tarefa?');
            }
            return true;
        }
    </script>
     <a href="../index.php">Sair</a>

</body>
</html>

<?php
include('conexao.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $setor = $_POST['setor'];
    $senha = $_POST['senha'];

    if (!empty($nome) && !empty($setor) && !empty($senha)) {
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, setor, senha) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nome, $setor, $senha);
        $stmt->execute();
        header("Location: ../index.php");
        exit();
    } else {
        $erro = "Preencha todos os campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="../frontend/style.css" />
</head>
<body>
    <h2>Cadastro de Usuário</h2>

    <?php if (isset($erro)) : ?>
        <p style="color:red;"><?= $erro ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="nome">Nome:</label><br />
        <input type="text" id="nome" name="nome" required /><br /><br />

        <label for="setor">Setor:</label><br />
        <select id="setor" name="setor" required>
            <option value="" selected>Selecione seu setor</option>
            <option value="Administracao">Administração</option>
            <option value="Financeiro">Financeiro</option>
            <option value="Juridico">Jurídico</option>
            <option value="Logistica">Logística</option>
            <option value="Producao">Produção</option>
            <option value="Recursos Humanos">Recursos Humanos</option>
        </select><br /><br />

        <label for="senha">Senha:</label><br />
        <input type="password" id="senha" name="senha" maxlength="16" required /><br /><br />

        <input type="submit" value="Cadastrar" />
    </form>

    <p><a href="../index.php">Voltar ao Login</a></p>
</body>
</html>

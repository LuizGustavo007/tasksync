<?php
include('conexao.php');


$usuarios = $conn->query("SELECT id, nome FROM usuarios");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_usuario = $_POST['id_usuario'];
    $descricao = $_POST['descricao'];
    $prioridade = $_POST['prioridade'];

    if (!empty($id_usuario) && !empty($descricao) && !empty($prioridade)) {
        
        $stmt = $conn->prepare("SELECT setor FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $stmt->bind_result($setor);
        $stmt->fetch();
        $stmt->close();

        
        $stmt = $conn->prepare("INSERT INTO tarefas (id_usuario, descricao, setor, prioridade) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $id_usuario, $descricao, $setor, $prioridade);
        $stmt->execute();

        header("Location: gerenciar_tarefas.php");
        exit();
    } else {
        $erro = "Todos os campos são obrigatórios.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Tarefa</title>
    <link rel="stylesheet" href="../frontend/style.css">
</head>
<body>
    <h2>Cadastrar Nova Tarefa</h2>
    <?php if (isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>

    <form method="post">
        <label for="id_usuario">Usuário:</label><br>
        <select name="id_usuario" required>
            <option value="">Selecione o usuário</option>
            <?php while ($row = $usuarios->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <label for="descricao">Descrição:</label><br>
        <textarea name="descricao" required></textarea><br><br>

        

        <label for="prioridade">Prioridade:</label><br>
        <select name="prioridade" required>
            <option value="">Selecione</option>
            <option value="baixa">Baixa</option>
            <option value="média">Média</option>
            <option value="alta">Alta</option>
        </select><br><br>

        <input type="submit" value="Cadastrar Tarefa">
    </form>

    <p><a href="gerenciar_tarefas.php">Gerenciar Tarefas</a></p>
     <a href="../index.php">Sair</a>
</body>
</html>
